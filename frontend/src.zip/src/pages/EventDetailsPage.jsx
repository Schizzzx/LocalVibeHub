// src/pages/EventDetailsPage.js
import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from '../utils/axiosInstance';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import { motion } from 'framer-motion';

const EventDetailsPage = () => {
  const { id } = useParams(); // Event ID from URL parameters
  const navigate = useNavigate();

  const [event, setEvent] = useState(null); // State for storing event data
  const [username, setUsername] = useState('User'); // Logged-in username
  const [message, setMessage] = useState(''); // Message to display after actions
  const [error, setError] = useState(''); // Error message if event fails to load

  // Fetch event data and user profile on page load
  const fetchEvent = useCallback(async () => {
    try {
      const profileRes = await axios.get('/api/users/profile'); // Get profile data
      setUsername(profileRes.data.user.username); // Set logged-in username

      const res = await axios.get(`/api/events/${id}`); // Fetch event data by ID
      setEvent(res.data); // Set event data
    } catch (err) {
      console.error('Failed to fetch event:', err);
      setError('Failed to load event details.'); // Set error message on failure
    }
  }, [id]); // Dependency on event ID to refetch data if it changes

  // Handle event registration
  const handleRegister = async () => {
    try {
      await axios.post(`/api/events/${id}/register`); // Send request to register for event
      setMessage('Successfully registered!'); // Display success message
    } catch (err) {
      console.error('Registration failed:', err);
      setMessage(err.response?.data?.error || 'Registration failed.'); // Display error message
    }
  };

  // Handle event reporting
  const handleReport = async () => {
    const reason = prompt('Please describe the issue with this event:'); // Prompt user for report reason
    if (!reason || !reason.trim()) return; // Do nothing if reason is empty

    try {
      await axios.post('/api/reports', {
        report_type: 'event', // Report for an event
        target_id: Number(id), // Event ID to report
        reason, // Reason for the report
      });
      alert('Thank you. The event has been reported.'); // Success alert
    } catch (err) {
      console.error('Report failed:', err);
      alert('Failed to submit report.'); // Failure alert
    }
  };

  // Add event to favorites
  const handleAddFavorite = async () => {
    try {
      await axios.post('/api/favorites', {
        event_id: Number(id) // Send event ID to be added to favorites
      });
      setMessage('Event added to favorites!'); // Display success message
    } catch (err) {
      console.error('Failed to add favorite:', err);
      setMessage('Failed to add to favorites.'); // Display error message
    }
  };

  // useEffect to fetch event and user profile data when component mounts
  useEffect(() => {
    fetchEvent(); // Fetch event data on page load
  }, [fetchEvent]);

  return (
    <div className="min-h-screen bg-background text-text flex flex-col">
      <NavPanelLoggedIn username={username} /> {/* Navigation panel with the logged-in username */}

      <main className="flex-grow px-6 py-10">
        <motion.div 
          className="bg-panel p-6 rounded-xl max-w-5xl mx-auto shadow-lg"
          initial={{ opacity: 0, y: 30 }} // Animation to fade in and slide up
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }} // Animation transition
        >
          {/* Conditional rendering: show loading/error message if event is not loaded */}
          {!event ? (
            <p className="text-center text-red-500">{error || 'Loading...'}</p> // Display loading/error message
          ) : (
            <>
              <motion.h1 
                className="text-3xl font-bold mb-2"
                initial={{ opacity: 0 }} // Initial animation state
                animate={{ opacity: 1 }} // End animation state
                transition={{ delay: 0.2 }} // Delay for animation
              >
                {event.title} {/* Display event title */}
              </motion.h1>

              <div className="mb-4 text-lg">
                <strong>Organiser:</strong>{' '}
                {event.organizer_username ? (
                  <button
                    onClick={() => navigate(`/user/${event.organizer_id}/public-profile`)} // Navigate to organizer's public profile
                    className="text-accent underline hover:text-opacity-80 text-lg font-semibold"
                  >
                    {event.organizer_username} {/* Display organizer username */}
                  </button>
                ) : (
                  'Unknown'
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <motion.div className="space-y-2 text-sm" initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.2 }}>
                  {/* Display event details */}
                  <p><strong>Address:</strong> {event.location}</p>
                  <p><strong>Time:</strong> {new Date(event.date).toLocaleString()}</p>
                  <p><strong>Age:</strong> {event.age_restriction || 0}+</p>
                  <p><strong>Price:</strong> {event.price || 0} euro</p>
                  <p><strong>Contacts:</strong> {event.contacts || 'N/A'}</p>
                  <p><strong>Link:</strong>{' '}
                    {event.link ? (
                      <a href={event.link} className="text-accent underline hover:text-opacity-80" target="_blank" rel="noreferrer">
                        {event.link} {/* Display external event link */}
                      </a>
                    ) : 'N/A'}
                  </p>
                </motion.div>

                <motion.div 
                  className="bg-white text-black rounded-xl p-6 text-center"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  {/* Display event image */}
                  {event.image_url ? (
                    <img src={event.image_url} alt="Event" className="w-full h-auto rounded-xl" />
                  ) : (
                    <p className="text-gray-500">No picture provided</p> // Default message if no image
                  )}
                </motion.div>
              </div>

              <motion.div className="mt-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
                <p><strong>Description:</strong></p>
                <p className="text-sm mt-2">{event.description}</p> {/* Display event description */}
              </motion.div>

              <motion.div className="mt-6 flex flex-wrap justify-between gap-3 items-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
                {/* Buttons for actions: Report, Add to favorites, Register */}
                <button
                  onClick={handleReport} // Report event action
                  className="bg-red-500 text-white px-6 py-2 rounded-xl hover:bg-red-600"
                >
                  Report this event
                </button>

                <button
                  onClick={handleAddFavorite} // Add event to favorites action
                  className="bg-yellow-400 text-black px-6 py-2 rounded-xl hover:bg-yellow-500"
                >
                  Add to favorites
                </button>

                <button
                  onClick={handleRegister} // Register for event action
                  className="bg-accent text-black px-6 py-2 rounded-xl"
                >
                  Register
                </button>
              </motion.div>

              {/* Display message if any action was performed */}
              {message && (
                <motion.p className="mt-4 text-center text-white" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}>
                  {message}
                </motion.p>
              )}
            </>
          )}
        </motion.div>
      </main>
      <Footer /> {/* Footer component */}
    </div>
  );
};

export default EventDetailsPage;
