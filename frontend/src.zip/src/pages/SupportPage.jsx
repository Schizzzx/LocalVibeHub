import React, { useState } from 'react';
import axios from '../utils/axiosInstance';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import { motion } from 'framer-motion';

const SupportPage = () => {
  // State variables to manage subject, message, and response
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState('');

  // Function to handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent form from reloading the page
    setResponse(''); // Clear any previous response message

    // Retrieve access token from localStorage or window object
    const token = localStorage.getItem('accessToken') || window.accessToken;

    // If there's no token, return an unauthorized response
    if (!token) return setResponse('Unauthorized');

    try {
      // Send support message to the server
      const res = await axios.post('http://localhost:5000/api/support', {
        subject,
        message,
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Set response message based on the server's response
      setResponse(res.data.message);
      setSubject(''); // Clear the subject input
      setMessage(''); // Clear the message input
    } catch (err) {
      // Handle errors and display them
      setResponse(err.response?.data?.error || 'Failed to send support message.');
    }
  };

  return (
    <div className="min-h-screen bg-background text-text flex flex-col">
      {/* Navigation panel with username */}
      <NavPanelLoggedIn username="User" />

      <main className="flex-grow px-8 py-10 flex justify-center items-start">
        {/* Main content container */}
        <motion.div
          className="bg-panel p-6 rounded-xl shadow-xl w-full max-w-xl"
          initial={{ opacity: 0, y: 40 }} // Initial animation settings
          animate={{ opacity: 1, y: 0 }} // Animation when the component is displayed
          transition={{ duration: 0.6 }} // Transition duration
        >
          <h1 className="text-2xl font-bold mb-4">Support</h1> {/* Title of the page */}

          {/* Form to send a support message */}
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {/* Input for the subject */}
            <motion.input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)} // Update subject state
              placeholder="Subject"
              required
              className="px-4 py-2 rounded bg-white text-black"
              initial={{ opacity: 0, x: -20 }} // Initial position and animation
              animate={{ opacity: 1, x: 0 }} // Final position and animation
              transition={{ delay: 0.2 }} // Delay the animation
            />
            {/* Textarea for the message */}
            <motion.textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)} // Update message state
              placeholder="Your message"
              required
              rows={5}
              className="px-4 py-2 rounded bg-white text-black"
              initial={{ opacity: 0, x: 20 }} // Initial position and animation
              animate={{ opacity: 1, x: 0 }} // Final position and animation
              transition={{ delay: 0.3 }} // Delay the animation
            />
            {/* Submit button */}
            <motion.button
              type="submit"
              className="bg-accent text-black px-4 py-2 rounded-xl"
              whileHover={{ scale: 1.05 }} // Button hover effect
              whileTap={{ scale: 0.95 }} // Button tap effect
            >
              Send Message
            </motion.button>

            {/* Display response message after submission */}
            {response && <p className="text-sm text-white mt-2">{response}</p>}
          </form>
        </motion.div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default SupportPage;
