import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from '../utils/axiosInstance';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import { motion } from 'framer-motion';

const RegisteredUsersPage = () => {
  const { eventId } = useParams(); // Extract event ID from URL parameters
  const [users, setUsers] = useState([]); // State to store list of users registered for the event
  const [username, setUsername] = useState('User'); // State to store the username of the logged-in user
  const [loading, setLoading] = useState(true); // State to manage loading status
  const [error, setError] = useState(''); // State to manage error messages

  // Function to fetch registered users for the event
  const fetchRegisteredUsers = async () => {
    setLoading(true); // Set loading to true when starting to fetch data
    try {
      const token = localStorage.getItem('accessToken') || window.accessToken;
      if (!token) return setError('Unauthorized'); // Show error if token is not found

      // Fetch logged-in user profile to set the username
      const profileRes = await axios.get('/api/users/profile', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsername(profileRes.data.user.username);

      // Fetch users registered for the current event
      const res = await axios.get(`/api/events/${eventId}/registered-users`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Set the users state with the registered users data
      setUsers(res.data || []);
    } catch (err) {
      console.error('Failed to load registered users:', err);
      setError('Failed to load registered users.'); // Set error if fetching data fails
    } finally {
      setLoading(false); // Stop loading once data is fetched or error occurs
    }
  };

  // Function to handle user unregistration from the event
  const handleCancelRegistration = async (userId) => {
    const confirm = window.confirm('Are you sure you want to remove this user from the event?');
    if (!confirm) return; // If the user cancels the action, do nothing

    try {
      const token = localStorage.getItem('accessToken') || window.accessToken;
      // Send request to cancel user's registration from the event
      await axios.delete(`/api/events/${eventId}/unregister/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Update the users list by removing the user from the state
      setUsers((prev) => prev.filter((u) => u.id !== userId));
    } catch (err) {
      console.error('Failed to cancel registration:', err);
      alert('Failed to cancel registration.'); // Show alert if the cancellation fails
    }
  };

  // Fetch registered users when the component mounts or eventId changes
  useEffect(() => {
    fetchRegisteredUsers();
  }, [eventId]);

  return (
    <div className="min-h-screen bg-background text-text flex flex-col">
      <NavPanelLoggedIn username={username} />

      <main className="flex-grow px-6 py-10">
        <motion.div 
          className="bg-panel p-6 rounded-xl max-w-4xl mx-auto shadow-lg"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.h1 
            className="text-xl font-bold text-center mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Here is the list of people registered for this event:
          </motion.h1>

          {/* Conditional rendering based on loading, error, or events */}
          {loading ? (
            <p className="text-center">Loading...</p>
          ) : error ? (
            <p className="text-center text-red-500">{error}</p>
          ) : users.length === 0 ? (
            <p className="text-center">Nobody is registered for this event yet.</p>
          ) : (
            // Display list of users registered for the event
            <motion.div 
              className="flex flex-col gap-4 max-h-[600px] overflow-y-auto"
              initial="hidden"
              animate="visible"
              variants={{
                hidden: {},
                visible: {
                  transition: {
                    staggerChildren: 0.1,
                  },
                },
              }}
            >
              {users.map((user) => (
                <motion.div
                  key={user.id}
                  className="flex justify-between items-center bg-gray-300 text-black px-6 py-4 rounded-full"
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                >
                  <div>
                    <span className="font-semibold">{user.username}</span> | {user.email}
                  </div>
                  {/* Button to cancel user registration */}
                  <button
                    onClick={() => handleCancelRegistration(user.id)}
                    className="ml-4 text-red-600 hover:underline"
                  >
                    Cancel registration
                  </button>
                </motion.div>
              ))}
            </motion.div>
          )}
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default RegisteredUsersPage;
