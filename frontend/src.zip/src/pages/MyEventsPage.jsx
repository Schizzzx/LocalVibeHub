import React, { useEffect, useState } from 'react';
import axios from '../utils/axiosInstance';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const MyEventsPage = () => {
  // State hooks to manage events, user information, loading state, and error messages
  const [events, setEvents] = useState([]);
  const [username, setUsername] = useState('User');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // Function to fetch events created by the user and their profile information
  const fetchMyEvents = async () => {
    setLoading(true); // Start loading state
    setError(''); // Clear any previous errors

    try {
      const token = localStorage.getItem('accessToken') || window.accessToken; // Get token from localStorage
      if (!token) {
        setError('Unauthorized'); // Set error if no token found
        return;
      }

      // Fetch the profile of the current user
      const profileRes = await axios.get('/api/users/profile', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsername(profileRes.data.user.username); // Set username from the response

      // Fetch the events created by the user
      const eventsRes = await axios.get('/api/events/my-events', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEvents(eventsRes.data || []); // Set the fetched events to the state
    } catch (err) {
      console.error(err); // Log any error that occurs
      setError('Failed to load your events.'); // Set error message
    } finally {
      setLoading(false); // Stop loading state
    }
  };

  // Function to delete an event
  const handleDelete = async (eventId) => {
    const confirm = window.confirm('Are you sure you want to delete this event? This action cannot be undone.');
    if (!confirm) return; // If user cancels, return early

    try {
      const token = localStorage.getItem('accessToken') || window.accessToken; // Get token from localStorage
      // Delete the event using its ID
      await axios.delete(`/api/events/${eventId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEvents((prev) => prev.filter((e) => e.id !== eventId)); // Remove the event from the state
    } catch (err) {
      console.error(err); // Log error
      alert('Failed to delete event.'); // Show alert if deletion fails
    }
  };

  // Function to navigate to the event editing page
  const handleEditEvent = (eventId) => {
    navigate(`/edit-event/${eventId}`);
  };

  // Function to navigate to the registered users page for an event
  const handleWatchRegistered = (eventId) => {
    navigate(`/event/${eventId}/registered-users`);
  };

  // Fetch events and user profile on component mount
  useEffect(() => {
    fetchMyEvents();
  }, []);

  return (
    <div className="min-h-screen bg-background text-text flex flex-col">
      <NavPanelLoggedIn username={username} /> {/* Navbar component displaying the username */}

      <main className="flex-grow px-4 py-10">
        {/* Motion wrapper for smooth animations */}
        <motion.div
          className="bg-panel p-4 md:p-6 rounded-2xl max-w-3xl mx-auto shadow-lg"
          initial={{ opacity: 0, y: 50 }} // Initial animation state
          animate={{ opacity: 1, y: 0 }} // Final animation state
          transition={{ duration: 0.6 }} // Animation duration
        >
          <h1 className="text-xl md:text-2xl font-bold text-center mb-6">Events created by you</h1>

          {/* Display loading state or error message */}
          {loading ? (
            <p className="text-center">Loading...</p>
          ) : error ? (
            <p className="text-center text-red-500">{error}</p>
          ) : events.length === 0 ? ( // If no events found
            <p className="text-center">You have not created any events yet.</p>
          ) : (
            <motion.div
              className="flex flex-col gap-4 max-h-[500px] overflow-y-auto pr-1"
              initial="hidden"
              animate="visible"
              variants={{
                hidden: {},
                visible: {
                  transition: {
                    staggerChildren: 0.1, // Stagger children animation for smoother loading
                  }
                }
              }}
            >
              {/* Map through the events and display them */}
              {events.map((event) => (
                <motion.div
                  key={event.id}
                  className="flex justify-between items-center bg-gray-300 text-black px-4 py-3 rounded-2xl shadow-sm"
                  initial={{ opacity: 0, y: 20 }} // Initial animation state for each event
                  animate={{ opacity: 1, y: 0 }} // Final animation state for each event
                >
                  {/* Link to the event details page */}
                  <Link
                    to={`/event/${event.id}`}
                    className="w-full hover:underline"
                  >
                    <div className="font-semibold truncate">{event.title}</div>
                    <div className="text-sm truncate">
                      {event.location} | {event.date} | {event.age_restriction || 0}+ | {event.price || 0} euro
                    </div>
                  </Link>
                  <div className="flex flex-col md:flex-row gap-2 md:gap-4 ml-4 text-sm text-right shrink-0">
                    {/* Edit, Watch Registered, and Delete buttons */}
                    <button
                      onClick={() => handleEditEvent(event.id)}
                      className="text-yellow-600 hover:underline"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleWatchRegistered(event.id)}
                      className="text-blue-600 hover:underline"
                    >
                      Watch who are registered
                    </button>
                    <button
                      onClick={() => handleDelete(event.id)}
                      className="text-red-600 hover:underline"
                    >
                      Delete
                    </button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </motion.div>
      </main>

      <Footer /> {/* Footer component */}
    </div>
  );
};

export default MyEventsPage;
