// src/pages/EditProfilePage.js
import React, { useEffect, useState } from 'react';
import axios from '../utils/axiosInstance';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import { motion } from 'framer-motion';

// Available interest options for the user to select
const interestOptions = [
  'Concerts', 'Excursions', 'Board Games', 'Workshops',
  'Art', 'Tech', 'Parties', 'Networking'
];

const EditProfilePage = () => {
  // State to manage the form data and selected interests
  const [formData, setFormData] = useState({
    username: '',
    city: '',
    age: '',
    email: '',
    password: ''
  });

  const [selectedInterests, setSelectedInterests] = useState([]); // List of selected interests
  const [username, setUsername] = useState('User'); // Username of the logged-in user
  const [message, setMessage] = useState(''); // Message to display after profile update

  // useEffect hook to fetch and set user profile data when the component mounts
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const res = await axios.get('/api/users/profile'); // Fetch user profile data
        const user = res.data.user;

        setUsername(user.username); // Set the username
        setFormData({
          username: user.username || '',
          city: user.city || '',
          age: user.age || '',
          email: user.email || '',
          password: ''
        });

        const interestsRes = await axios.get('/api/users/interests'); // Fetch user's interests
        setSelectedInterests(interestsRes.data || []); // Set the selected interests
      } catch (err) {
        console.error('Error loading profile:', err); // Log any errors during the fetch
      }
    };

    fetchUserProfile(); // Fetch user profile data
  }, []); // Empty dependency array ensures this runs once on component mount

  // Toggle the selection of an interest
  const toggleInterest = (interest) => {
    setSelectedInterests((prev) =>
      prev.includes(interest)
        ? prev.filter((i) => i !== interest) // Remove interest if already selected
        : [...prev, interest] // Add interest if not selected
    );
  };

  // Handle change in input fields
  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value // Update the corresponding form field
    }));
  };

  // Handle form submission to update profile
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent the default form submission
    setMessage(''); // Reset the message state

    try {
      // Send a PUT request to update the user profile with the form data and selected interests
      await axios.put('/api/users/profile', {
        ...formData,
        interests: selectedInterests
      });

      setMessage('Profile updated successfully.'); // Show success message
    } catch (err) {
      console.error('Update error:', err); // Log error if the update fails
      setMessage('Failed to update profile.'); // Show failure message
    }
  };

  return (
    <div className="min-h-screen bg-background text-text flex flex-col">
      <NavPanelLoggedIn username={username} /> {/* Display the logged-in user's username in the navigation panel */}

      <main className="flex-grow px-6 py-10">
        <motion.div
          className="bg-panel p-6 rounded-xl max-w-5xl mx-auto shadow-lg"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-xl font-bold text-center mb-6">Change your profile</h1> {/* Profile page title */}

          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex flex-col gap-4">
              {/* Username input field */}
              <input
                type="text"
                name="username"
                placeholder="Your Name and Surname"
                value={formData.username}
                onChange={handleChange}
                required
                className="px-4 py-2 rounded-full bg-white text-black"
              />
              {/* City input field */}
              <input
                type="text"
                name="city"
                placeholder="Your City of Living"
                value={formData.city}
                onChange={handleChange}
                required
                className="px-4 py-2 rounded-full bg-white text-black"
              />
              {/* Age input field */}
              <input
                type="number"
                name="age"
                placeholder="Your Age"
                value={formData.age}
                onChange={handleChange}
                required
                className="px-4 py-2 rounded-full bg-white text-black"
              />
              {/* Email input field */}
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                value={formData.email}
                onChange={handleChange}
                required
                className="px-4 py-2 rounded-full bg-white text-black"
              />
              {/* Password input field */}
              <input
                type="password"
                name="password"
                placeholder="Your Password"
                value={formData.password}
                onChange={handleChange}
                className="px-4 py-2 rounded-full bg-white text-black"
              />
            </div>

            <div className="flex flex-col gap-4">
              <label>Your List of interests:</label> {/* Interests section label */}
              <div className="flex flex-wrap gap-2">
                {/* Render each interest option */}
                {interestOptions.map((interest) => (
                  <motion.button
                    type="button"
                    key={interest}
                    onClick={() => toggleInterest(interest)} // Toggle interest selection on button click
                    className={`px-4 py-2 rounded-xl transition-colors duration-200 ${
                      selectedInterests.includes(interest)
                        ? 'bg-accent text-black'
                        : 'bg-gray-700 text-white'
                    }`}
                    whileTap={{ scale: 0.95 }}
                    whileHover={{ scale: 1.05 }}
                  >
                    {interest} {/* Display interest name */}
                  </motion.button>
                ))}
              </div>

              {/* Submit button for profile update */}
              <button type="submit" className="mt-6 bg-accent text-black px-6 py-2 rounded-full">
                Save Changes
              </button>

              {message && (
                <p className="text-center text-sm mt-2 text-white">{message}</p> // Display success or error message
              )}
            </div>
          </form>
        </motion.div>
      </main>

      <Footer /> {/* Footer component */}
    </div>
  );
};

export default EditProfilePage;
