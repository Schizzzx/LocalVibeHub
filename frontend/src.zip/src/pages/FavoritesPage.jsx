import React, { useEffect, useState } from 'react';
import axios from '../utils/axiosInstance';
import { useNavigate } from 'react-router-dom';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import { motion, AnimatePresence } from 'framer-motion';

const FavoritesPage = () => {
  const [favorites, setFavorites] = useState([]); // Store list of favorite events
  const [username, setUsername] = useState('User'); // Store the logged-in user's username
  const navigate = useNavigate(); // Navigate between pages

  // Fetch user's favorites and profile data
  const fetchFavorites = async () => {
    try {
      const token = localStorage.getItem('accessToken'); // Retrieve token from local storage
      if (!token) return navigate('/?expired=1'); // Redirect if token is not found

      // Fetch user profile using the token
      const profileRes = await axios.get('/api/users/profile', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsername(profileRes.data.user.username); // Set username from profile response

      // Fetch favorite events for the user
      const res = await axios.get('/api/favorites', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFavorites(res.data); // Update favorites state with the fetched data
    } catch (err) {
      console.error('Failed to load favorites:', err); // Log error if fetching fails
    }
  };

  useEffect(() => {
    fetchFavorites(); // Call fetchFavorites when component mounts
  }, []);

  // Remove an event from the favorites list
  const handleRemove = async (eventId) => {
    try {
      const token = localStorage.getItem('accessToken'); // Get token from local storage
      // Remove the event from favorites via an API request
      await axios.delete(`/api/favorites/${eventId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFavorites((prev) => prev.filter((event) => event.id !== eventId)); // Update favorites after removal
    } catch (err) {
      console.error('Failed to remove favorite:', err); // Log error if removal fails
    }
  };

  return (
    <div className="min-h-screen bg-background text-text flex flex-col">
      <NavPanelLoggedIn username={username} /> {/* Render navigation panel with the username */}

      <main className="flex-grow px-6 py-10 max-w-5xl mx-auto">
        <motion.h1 
          className="text-2xl font-bold mb-4"
          initial={{ opacity: 0, y: -20 }} // Initial animation state
          animate={{ opacity: 1, y: 0 }} // Final animation state
          transition={{ duration: 0.5 }} // Transition duration for animation
        >
          Your Favorite Events
        </motion.h1>

        <AnimatePresence>
          {favorites.length === 0 ? ( // Check if there are no favorites
            <motion.p 
              className="text-gray-400"
              initial={{ opacity: 0 }} // Initial fade out
              animate={{ opacity: 1 }} // Fade in
              exit={{ opacity: 0 }} // Fade out when component unmounts
            >
              You haven’t added any events to favorites yet.
            </motion.p>
          ) : (
            <motion.div
              className="space-y-4"
              initial="hidden"
              animate="visible"
              variants={{
                hidden: {},
                visible: { transition: { staggerChildren: 0.1 } }, // Stagger children animation
              }}
            >
              {favorites.map((event) => ( // Loop through favorite events
                <motion.div
                  key={event.id}
                  className="bg-panel-light p-4 rounded-xl shadow flex justify-between items-center"
                  initial={{ opacity: 0, y: 10 }} // Initial animation state for each event
                  animate={{ opacity: 1, y: 0 }} // Final animation state
                  exit={{ opacity: 0, y: 10 }} // Exit animation state
                >
                  <div>
                    <p className="text-lg font-semibold">{event.title}</p> {/* Display event title */}
                    <p className="text-sm text-gray-400">{new Date(event.date).toLocaleString()}</p> {/* Display event date */}
                  </div>
                  <div className="flex gap-2">
                    <motion.button
                      onClick={() => navigate(`/event/${event.id}`)} // Navigate to event details
                      className="bg-accent text-black px-4 py-1.5 rounded-xl text-sm hover:bg-opacity-80"
                      whileHover={{ scale: 1.05 }} // Hover animation
                      whileTap={{ scale: 0.95 }} // Tap animation
                    >
                      View
                    </motion.button>
                    <motion.button
                      onClick={() => handleRemove(event.id)} // Handle removing the event from favorites
                      className="bg-red-500 text-white px-4 py-1.5 rounded-xl text-sm hover:bg-red-600"
                      whileHover={{ scale: 1.05 }} // Hover animation
                      whileTap={{ scale: 0.95 }} // Tap animation
                    >
                      Remove
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <Footer /> {/* Render footer */}
    </div>
  );
};

export default FavoritesPage; // Export the component for use in other parts of the app
