// src/pages/EditEventPage.js
import React, { useEffect, useState } from 'react';
import axios from '../utils/axiosInstance';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import { useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';

// Available event categories for selection
const categories = ['Concerts', 'Art', 'Sports', 'Tech', 'Networking', 'Education', 'Food', 'Games'];

const EditEventPage = () => {
  const { id } = useParams(); // Get event ID from URL
  const navigate = useNavigate(); // Hook to handle navigation
  const token = localStorage.getItem('accessToken'); // Retrieve stored access token

  // States for user, event data, and error handling
  const [username, setUsername] = useState('');
  const [eventData, setEventData] = useState({
    title: '',
    location: '',
    date: '',
    price: '',
    contacts: '',
    link: '',
    description: '',
    category: '',
  });
  const [error, setError] = useState(''); // Error message state

  // Effect hook to fetch data on component mount
  useEffect(() => {
    if (!token) return navigate('/login'); // Redirect to login if no token is found

    // Fetch event data based on event ID
    const fetchEventData = async () => {
      try {
        const res = await axios.get(`/api/events/${id}`);
        setEventData(res.data); // Set event data to state
      } catch (err) {
        console.error('Failed to load event:', err); // Log error if data fetch fails
        setError('Failed to load event data.'); // Set error message
      }
    };

    // Fetch user data to display username
    const fetchUser = async () => {
      try {
        const res = await axios.get('/api/users/me');
        setUsername(res.data.username); // Set username from fetched user data
      } catch (err) {
        console.error('Failed to load user:', err); // Log error if user data fetch fails
        localStorage.removeItem('accessToken'); // Remove invalid token
        navigate('/login'); // Redirect to login page
      }
    };

    fetchUser(); // Fetch user data
    fetchEventData(); // Fetch event data
  }, [id, navigate, token]);

  // Generic input change handler
  const handleChange = (e) => {
    const { name, value } = e.target; // Destructure input name and value
    setEventData((prev) => ({ ...prev, [name]: value })); // Update state with input value
  };

  // Handle category selection
  const handleCategorySelect = (selectedCategory) => {
    setEventData((prev) => ({ ...prev, category: selectedCategory })); // Set selected category to event data
  };

  // Form submission handler
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission
    try {
      // Update event data by sending a PUT request to the backend
      await axios.put(`/api/events/${id}/edit`, eventData);
      alert('Event updated successfully!'); // Display success message
      navigate('/my-events'); // Navigate to "my events" page after successful update
    } catch (err) {
      console.error('Failed to update event:', err); // Log error if update fails
      alert('Failed to update event.'); // Display failure message
    }
  };

  return (
    <div className="h-screen bg-background text-text flex flex-col overflow-hidden">
      <NavPanelLoggedIn username={username} /> {/* Display the logged-in user's username in the navigation panel */}

      <main className="flex-grow p-6 flex justify-center items-center overflow-hidden">
        <motion.div
          className="w-full max-w-3xl h-[600px] bg-panel p-6 rounded-xl shadow-md overflow-y-auto"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.h1
            className="text-2xl font-bold text-center mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Edit Event
          </motion.h1>

          {error && <p className="text-red-500 text-center">{error}</p>} {/* Display error message if any */}

          <form onSubmit={handleSubmit} className="space-y-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              {/* Event title input */}
              <input
                type="text"
                name="title"
                placeholder="Title"
                value={eventData.title}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 rounded-lg bg-gray-100 text-black"
              />
              {/* Event location input */}
              <input
                type="text"
                name="location"
                placeholder="Location"
                value={eventData.location}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 mt-2 rounded-lg bg-gray-100 text-black"
              />
              {/* Event date input */}
              <input
                type="datetime-local"
                name="date"
                value={eventData.date?.slice(0, 16) || ''}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 mt-2 rounded-lg bg-gray-100 text-black"
              />
              {/* Event price input */}
              <input
                type="number"
                name="price"
                placeholder="Price in euros"
                value={eventData.price}
                onChange={handleChange}
                className="w-full px-4 py-2 mt-2 rounded-lg bg-gray-100 text-black"
              />
              {/* Event contacts input */}
              <input
                type="text"
                name="contacts"
                placeholder="Contact information"
                value={eventData.contacts}
                onChange={handleChange}
                className="w-full px-4 py-2 mt-2 rounded-lg bg-gray-100 text-black"
              />
              {/* Event link input */}
              <input
                type="text"
                name="link"
                placeholder="External link or social"
                value={eventData.link}
                onChange={handleChange}
                className="w-full px-4 py-2 mt-2 rounded-lg bg-gray-100 text-black"
              />
            </motion.div>

            <div>
              <p className="mb-2 font-medium">Select category:</p>
              <div className="flex flex-wrap gap-2">
                {/* Category selection buttons */}
                {categories.map((cat) => (
                  <motion.button
                    key={cat}
                    type="button"
                    onClick={() => handleCategorySelect(cat)} // Set category on button click
                    className={`px-4 py-2 rounded-full border transition ${
                      eventData.category === cat
                        ? 'bg-black text-white'
                        : 'bg-gray-200 text-black hover:bg-gray-300'
                    }`}
                    whileTap={{ scale: 0.95 }}
                  >
                    {cat}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Event description input */}
            <textarea
              name="description"
              placeholder="Description"
              value={eventData.description}
              onChange={handleChange}
              className="w-full px-4 py-2 rounded-lg bg-gray-100 text-black"
              rows={4}
            />

            {/* Submit button */}
            <motion.button
              type="submit"
              className="w-full bg-black text-white py-2 rounded-lg hover:bg-opacity-90 transition"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
            >
              Save Changes
            </motion.button>
          </form>
        </motion.div>
      </main>

      <Footer /> {/* Footer component */}
    </div>
  );
};

export default EditEventPage;
