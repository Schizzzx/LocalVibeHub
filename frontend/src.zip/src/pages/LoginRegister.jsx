import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import axios from '../utils/axiosInstance';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const LoginRegister = () => {
  const navigate = useNavigate(); // To navigate between pages
  const [mode, setMode] = useState('login'); // Track whether it's 'login' or 'register' mode
  const [formData, setFormData] = useState({
    username: '', // User's username
    email: '', // User's email
    password: '', // User's password
    confirmPassword: '', // User's password confirmation (only in register mode)
  });
  const [message, setMessage] = useState(''); // Message to show success/error

  // Handle form input changes
  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value, // Update the specific form field
    }));
  };

  // Handle form submission (either login or register)
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent page reload on form submit
    setMessage(''); // Reset message on form submit

    // Check if passwords match in register mode
    if (mode === 'register' && formData.password !== formData.confirmPassword) {
      setMessage('Passwords do not match.'); // Set error message if passwords don't match
      return;
    }

    const endpoint = mode === 'login' // Set endpoint based on mode
      ? '/api/users/login'
      : '/api/users/register';

    try {
      const payload = mode === 'login'
        ? { email: formData.email, password: formData.password } // Login payload
        : { username: formData.username, email: formData.email, password: formData.password }; // Register payload

      const response = await axios.post(endpoint, payload); // Make API request for login or register
      const { accessToken } = response.data; // Get access token from response

      window.accessToken = accessToken; // Store the access token in window object
      setTimeout(() => {
        localStorage.setItem('accessToken', accessToken); // Save access token in localStorage
        console.log('TOKEN SAVED TO LOCALSTORAGE'); // Debugging log
      }, 0);

      // After successful login/register, navigate based on the user role
      setTimeout(async () => {
        try {
          const meRes = await axios.get('/api/users/me'); // Get current user info
          const role = meRes.data.role; // Get the user's role

          // Redirect to appropriate page based on role
          if (role === 1) {
            navigate('/admin'); // Admin user
          } else if (mode === 'login') {
            navigate('/main'); // Regular user after login
          } else {
            navigate('/setup'); // New user after registration
          }
        } catch (meErr) {
          console.error('Failed to fetch user role after login:', meErr); // Handle error fetching user info
          setMessage('Something went wrong. Try again.'); // Set error message
        }
      }, 100);

      setMessage(response.data.message || 'Success!'); // Display success message
    } catch (error) {
      console.error('Login/Register error:', error); // Handle API error
      setMessage(error.response?.data?.error || 'Error. Try again.'); // Set error message if request fails
    }
  };

  return (
    <div className="min-h-screen bg-background text-text flex flex-col">
      <Navbar /> {/* Render the Navbar component */}

      <div className="flex-grow flex flex-col items-center justify-center">
        <motion.h1
          className="text-2xl font-bold bg-panel px-6 py-2 rounded-full mb-8"
          initial={{ opacity: 0, y: -10 }} // Initial animation state
          animate={{ opacity: 1, y: 0 }} // Final animation state
          transition={{ duration: 0.4 }} // Transition duration
        >
          Registrational Page
        </motion.h1>

        <motion.div
          className="bg-panel p-8 rounded-[90px] w-full max-w-md shadow-md"
          initial={{ scale: 0.95, opacity: 0 }} // Initial animation state
          animate={{ scale: 1, opacity: 1 }} // Final animation state
          transition={{ duration: 0.4 }} // Transition duration
        >
          {/* Toggle between Login and Register forms */}
          <div className="flex justify-around mb-6">
            <motion.button
              onClick={() => setMode('register')}
              className={`px-4 py-2 rounded-xl ${
                mode === 'register'
                  ? 'bg-accent text-black'
                  : 'bg-gray-700 text-white'
              }`}
              whileTap={{ scale: 0.95 }} // Animation on tap
              transition={{ duration: 0.2 }} // Transition duration
            >
              Sign In
            </motion.button>
            <motion.button
              onClick={() => setMode('login')}
              className={`px-4 py-2 rounded-xl ${
                mode === 'login'
                  ? 'bg-accent text-black'
                  : 'bg-gray-700 text-white'
              }`}
              whileTap={{ scale: 0.95 }} // Animation on tap
              transition={{ duration: 0.2 }} // Transition duration
            >
              Log In
            </motion.button>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <AnimatePresence mode="wait">
              {/* Show the username field only in register mode */}
              {mode === 'register' && (
                <motion.input
                  key="username"
                  type="text"
                  name="username"
                  placeholder="Username"
                  className="px-4 py-2 rounded bg-white text-black"
                  value={formData.username}
                  onChange={handleChange}
                  required
                  initial={{ opacity: 0, y: -10 }} // Initial animation state
                  animate={{ opacity: 1, y: 0 }} // Final animation state
                  exit={{ opacity: 0, y: 10 }} // Exit animation state
                  transition={{ duration: 0.2 }} // Transition duration
                />
              )}
            </AnimatePresence>

            <input
              type="email"
              name="email"
              placeholder="Email"
              className="px-4 py-2 rounded bg-white text-black"
              value={formData.email}
              onChange={handleChange}
              required
            />

            <input
              type="password"
              name="password"
              placeholder="Password"
              className="px-4 py-2 rounded bg-white text-black"
              value={formData.password}
              onChange={handleChange}
              required
            />

            <AnimatePresence mode="wait">
              {/* Show the confirmPassword field only in register mode */}
              {mode === 'register' && (
                <motion.input
                  key="confirm"
                  type="password"
                  name="confirmPassword"
                  placeholder="Repeat Password"
                  className="px-4 py-2 rounded bg-white text-black"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                  initial={{ opacity: 0, y: -10 }} // Initial animation state
                  animate={{ opacity: 1, y: 0 }} // Final animation state
                  exit={{ opacity: 0, y: 10 }} // Exit animation state
                  transition={{ duration: 0.2 }} // Transition duration
                />
              )}
            </AnimatePresence>

            <motion.button
              type="submit"
              className="bg-accent text-black px-4 py-2 rounded-xl mt-4"
              whileHover={{ scale: 1.05 }} // Animation on hover
              whileTap={{ scale: 0.95 }} // Animation on tap
              transition={{ duration: 0.2 }} // Transition duration
            >
              Enter
            </motion.button>

            {message && (
              <motion.div
                className="text-sm mt-4 text-center text-white"
                initial={{ opacity: 0 }} // Initial animation state
                animate={{ opacity: 1 }} // Final animation state
                transition={{ duration: 0.3 }} // Transition duration
              >
                {message} {/* Show success/error message */}
              </motion.div>
            )}
          </form>
        </motion.div>
      </div>
      <Footer /> {/* Render the Footer component */}
    </div>
  );
};

export default LoginRegister; // Export the LoginRegister component for use in other parts of the app
