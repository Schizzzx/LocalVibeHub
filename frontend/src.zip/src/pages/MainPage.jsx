import React, { useEffect, useState } from 'react';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import axios from '../utils/axiosInstance';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const MainPage = () => {
  // State hooks for managing user data, events, loading state, and errors
  const [events, setEvents] = useState([]); 
  const [user, setUser] = useState(null); 
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Function to wait for the access token to be available in localStorage
  const waitForToken = () => {
    return new Promise((resolve, reject) => {
      const maxAttempts = 10; // Maximum number of attempts to find the token
      let attempts = 0;

      const check = () => {
        const token = localStorage.getItem('accessToken') || window.accessToken;
        if (token) return resolve(token); // If token is found, resolve promise
        attempts++;
        if (attempts >= maxAttempts) return reject(new Error('Token not found')); // Reject if max attempts reached
        setTimeout(check, 100); // Retry every 100ms if token is not found
      };

      check();
    });
  };

  // Fetch user profile and recommended events
  useEffect(() => {
    const fetchProfileAndEvents = async () => {
      setLoading(true); // Set loading to true while data is being fetched
      try {
        const token = await waitForToken(); // Wait for the access token

        const profileRes = await axios.get('/api/users/profile', {
          headers: { Authorization: `Bearer ${token}` } // Fetch user profile using token
        });

        setUser(profileRes.data.user); // Set the user data from response

        const eventsRes = await axios.get('/api/events/recommended', {
          headers: { Authorization: `Bearer ${token}` } // Fetch recommended events using token
        });

        setEvents(eventsRes.data || []); // Set the recommended events data
      } catch (err) {
        console.error('MainPage error:', err); // Handle errors while fetching data
        localStorage.removeItem('accessToken'); // Remove token if error occurs
        window.location.href = '/?expired=1'; // Redirect to login page if error occurs
      } finally {
        setLoading(false); // Set loading to false after data is fetched
      }
    };

    fetchProfileAndEvents(); // Call the function to fetch profile and events
  }, []); // Empty dependency array ensures it runs only once when the component mounts

  return (
    <div className="min-h-screen bg-background text-text flex flex-col overflow-hidden">
      {/* Navigation panel with username */}
      <NavPanelLoggedIn username={user?.username || 'User'} />

      <main className="flex flex-grow px-8 py-10 gap-6 overflow-hidden">
        {/* Section for welcome message */}
        <motion.section
          className="w-full max-w-xs bg-panel p-6 rounded-xl shadow-md h-[550px]"
          initial={{ opacity: 0, x: -30 }} // Initial animation state
          animate={{ opacity: 1, x: 0 }} // Final animation state
          transition={{ duration: 0.4 }} // Transition duration
        >
          <p className="mb-4 pl-2">Dear <strong>{user?.username || 'user'}</strong>,</p>
          <p className="pl-2">Welcome to the main page of the LocalVibe Hub website.</p>
          <p className="mt-4 pl-2">On this page you will be able to see recommended events in your city and learn more about them.</p>
          <p className="mt-4 pl-2">You can change the data for your recommendations in your profile.</p>
        </motion.section>

        {/* Section for displaying the list of recommended events */}
        <motion.section
          className="flex-1 bg-panel p-6 rounded-xl shadow-md h-[550px] overflow-y-auto"
          initial={{ opacity: 0, x: 30 }} // Initial animation state
          animate={{ opacity: 1, x: 0 }} // Final animation state
          transition={{ duration: 0.4 }} // Transition duration
        >
          <h2 className="text-xl font-bold mb-4 text-center">Your recommendations</h2>

          {loading ? ( // If loading, show loading message
            <p className="text-center">Loading...</p>
          ) : error ? ( // If there's an error, show error message
            <p className="text-center text-red-500">{error}</p>
          ) : events.length > 0 ? ( // If events are available, display them
            <div className="flex flex-col gap-4">
              {events.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }} // Initial animation state for each event
                  animate={{ opacity: 1, y: 0 }} // Final animation state for each event
                  transition={{ delay: index * 0.05 }} // Delay animation for each event
                >
                  <Link
                    to={`/event/${event.id}`} // Link to the event details page
                    className="flex flex-col bg-gray-300 text-black px-6 py-4 rounded-xl shadow-md hover:bg-gray-200 transition duration-300"
                  >
                    <span className="font-semibold text-lg mb-1">{event.title}</span>
                    <span className="text-sm">
                      {event.location} | {new Date(event.date).toLocaleString()} | {event.age_restriction || 0}+ | {event.price || 0} euro
                    </span>
                  </Link>
                </motion.div>
              ))}
            </div>
          ) : ( // If no events are available, show this message
            <p className="text-center text-sm">No recommendations found.</p>
          )}
        </motion.section>
      </main>

      {/* Footer component */}
      <Footer />
    </div>
  );
};

export default MainPage; // Export the component
