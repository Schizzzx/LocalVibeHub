// src/pages/Welcome.js
import React from 'react';
import Navbar from '../components/Navbar'; // Importing the Navbar component
import Footer from '../components/Footer'; // Importing the Footer component
import { useNavigate } from 'react-router-dom'; // useNavigate hook from React Router to navigate between pages
import PageWrapper from '../components/PageWrapper'; // Importing a wrapper component for the page layout

const Welcome = () => {
  const navigate = useNavigate(); // Initialize navigate function to handle redirection

  // Function to handle the "Join Now" button click
  const handleJoinNow = () => {
    navigate('/login'); // Navigate to the login page for registration or login
  };

  return (
    <PageWrapper> {/* PageWrapper is used to wrap the content and provide consistent layout */}
      <div className="min-h-screen bg-background text-text flex flex-col justify-between">
        <Navbar /> {/* Render the navigation bar at the top of the page */}

        <main className="flex-grow flex items-center justify-center"> {/* Main content area */}
          <div className="bg-panel rounded-xl p-10 max-w-3xl text-center shadow-lg">
            {/* Text content introducing the website */}
            <p className="text-lg mb-6">
              Welcome to the LocalVibe HUB website. The website made by people for people.
              Smth like that. In the final version, the text will be different. It will be some welcoming
              text to ask people to register and start looking for or creating events.
            </p>

            {/* Button to initiate the registration/login process */}
            <button
              onClick={handleJoinNow} // Trigger the handleJoinNow function when clicked
              className="mt-4 bg-accent text-text-on-light px-6 py-3 rounded-xl font-semibold hover:bg-opacity-80"
            >
              Join Now
            </button>
          </div>
        </main>

        <Footer /> {/* Render the footer at the bottom of the page */}
      </div>
    </PageWrapper>
  );
};

export default Welcome;
