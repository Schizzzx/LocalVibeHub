// src/pages/FAQPage.js
import React from 'react';
import NavPanelLoggedIn from '../components/NavPanelLoggedIn';
import Footer from '../components/Footer';
import { motion } from 'framer-motion';

const FAQPage = () => {
  return (
    <div className="min-h-screen bg-background text-text flex flex-col">
      {/* Navigation Panel for Logged-in Users */}
      <NavPanelLoggedIn username="User" />

      <main className="flex-grow p-8 flex items-center justify-center">
        {/* Motion div with animation for the FAQ content */}
        <motion.div
          className="text-center max-w-xl"
          initial={{ opacity: 0, y: 20 }} // Initial state: hidden and slightly moved down
          animate={{ opacity: 1, y: 0 }} // Final state: fully visible and moved to original position
          transition={{ duration: 0.5 }} // Animation duration of 0.5 seconds
        >
          <h1 className="text-3xl font-bold mb-4">FAQ</h1>
          {/* Motion paragraph with a slight delay in opacity transition */}
          <motion.p
            className="text-lg"
            initial={{ opacity: 0 }} // Initial state: hidden
            animate={{ opacity: 1 }} // Final state: visible
            transition={{ delay: 0.3 }} // Animation delay of 0.3 seconds
          >
            Frequently Asked Questions will appear here soon.
          </motion.p>
        </motion.div>
      </main>

      <Footer /> {/* Footer component displayed at the bottom of the page */}
    </div>
  );
};

export default FAQPage;
