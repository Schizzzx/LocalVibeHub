// src/components/Footer.js

import React from 'react';

// Footer component displayed at the bottom of every page
const Footer = () => {
  return (
    <footer className="w-full bg-panel text-text mt-8 py-4 px-6 flex flex-col md:flex-row justify-between items-center gap-4">
      
      {/* University attribution (left side) */}
      <a
        href="https://www.lu.lv/"
        target="_blank"
        rel="noopener noreferrer"
        className="text-sm font-light text-text hover:no-underline"
        style={{ textDecoration: 'none' }}
      >
        Made for LU
      </a>

      {/* Placeholder contact links (right side) */}
      {/* NOTE: All links currently redirect to a rickroll. */}
      {/* Sorry for the rickrolls — author didn’t have time to insert real contact data before the deadline. */}
      {/* These will be updated with actual contact links in the future. */}
      <div className="w-full flex flex-col sm:flex-row gap-3">
        {['email', 'phone number', 'Telegram', 'Discord'].map((label) => (
          <a
            key={label}
            href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" // 🧨 placeholder rickroll link
            target="_blank"
            rel="noopener noreferrer"
            className="bg-accent text-black px-4 py-2 rounded-xl flex-grow text-center no-underline hover:no-underline"
          >
            {label}
          </a>
        ))}
      </div>
    </footer>
  );
};

export default Footer;
