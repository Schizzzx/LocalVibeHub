// src/components/Navbar.js

import React from 'react';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();

  // Hardcoded authentication status (should be dynamic in the future)
  const isAuthenticated = false;

  // Handles logo click: redirects to main page if logged in, welcome page otherwise
  const handleLogoClick = () => {
    if (isAuthenticated) {
      navigate('/main');
    } else {
      navigate('/');
    }
  };

  // Redirects to login page (used for all buttons in this guest-only version)
  const handleRedirectToLogin = () => {
    navigate('/login');
  };

  return (
    <nav className="w-full bg-panel text-text py-4 px-6 flex items-center justify-between shadow-md">
      
      {/* Logo button — acts as a home link based on auth status */}
      <button
        onClick={handleLogoClick}
        className="text-2xl font-bold"
        style={{ textDecoration: 'none' }}
      >
        LocalVibe HUB
      </button>

      {/* Navigation buttons (only shown to unauthenticated users) */}
      {/* NOTE: All buttons currently redirect to login due to hardcoded auth */}
      <div className="flex gap-4">

        {/* Search for events — future redirect to /search */}
        <button
          onClick={handleRedirectToLogin}
          className="bg-accent text-text-on-light px-4 py-2 rounded-xl hover:bg-opacity-80"
        >
          Search for events 
        </button>

        {/* Create an event — future redirect to /create */}
        <button
          onClick={handleRedirectToLogin}
          className="bg-accent text-text-on-light px-4 py-2 rounded-xl hover:bg-opacity-80"
        >
          Create an event 
        </button>

        {/* Auth button — redirect to login/registration page */}
        <button
          onClick={handleRedirectToLogin}
          className="bg-accent text-text-on-light px-4 py-2 rounded-xl hover:bg-opacity-80"
        >
          Log in / Sign in
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
