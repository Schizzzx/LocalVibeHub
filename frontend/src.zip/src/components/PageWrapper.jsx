import { motion } from 'framer-motion';

// Animation states for page transitions
const pageVariants = {
  initial: { opacity: 0, y: 20 },    // Before animation starts
  animate: { opacity: 1, y: 0 },     // Final visible state
  exit: { opacity: 0, y: -20 },      // Exit animation when page unmounts
};

// Transition settings (spring-based animation)
const pageTransition = {
  type: 'spring',
  stiffness: 100,
  damping: 20,
  duration: 0.4, // Optional, ignored in spring
};

// Wrapper component that applies page transition animations
export default function PageWrapper({ children }) {
  return (
    <motion.div
      initial="initial"
      animate="animate"
      exit="exit"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen flex flex-col"
    >
      {children}
    </motion.div>
  );
}
