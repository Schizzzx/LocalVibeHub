// src/components/RequireAdmin.js

import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import axios from '../utils/axiosInstance';

// Higher-order component to restrict access to admin-only routes
const RequireAdmin = ({ children }) => {
  const [loading, setLoading] = useState(true);     // Access check in progress
  const [isAdmin, setIsAdmin] = useState(false);    // Admin role flag

  useEffect(() => {
    const checkRole = async () => {
      try {
        // Fetch current user info
        const res = await axios.get('/api/users/me');
        if (res.data.role === 1) {
          setIsAdmin(true); // Grant access if user is admin
        }
      } catch (err) {
        console.warn('Access denied or not authenticated'); // Log warning on failure
      } finally {
        setLoading(false); // Done checking
      }
    };

    checkRole();
  }, []);

  // Show loading state while checking access
  if (loading) return <div className="text-center p-10">Checking access...</div>;

  // Redirect if user is not an admin
  if (!isAdmin) return <Navigate to="/" replace />;

  // Render children if admin access granted
  return children;
};

export default RequireAdmin;
