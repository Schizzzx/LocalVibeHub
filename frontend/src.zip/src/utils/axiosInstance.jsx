// src/utils/axiosinstance.js

import axios from 'axios';

// Create a custom Axios instance.
// All requests will go through this instance.
// Base URL is '/' — Vite proxy handles backend redirection.
const instance = axios.create({
  baseURL: '/',
  withCredentials: false, // We're using token-based auth, no cookies needed.
});

// Inject accessToken dynamically before every request.
// Supports both localStorage and window-scoped tokens (for flexibility).
instance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken') || window.accessToken;
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Global response interceptor for error handling.
// If token is invalid or expired, clean up and redirect to welcome page.
instance.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error?.response?.status;
    if (status === 401 || status === 403) {
      localStorage.removeItem('accessToken');
      localStorage.setItem('sessionExpired', 'true');
      window.location.href = '/?expired=1';
    }
    return Promise.reject(error);
  }
);

export default instance;
